Source: https://www.kaggle.com/datamunge/sign-language-mnist

train_augmented was collected manually by members of our team
